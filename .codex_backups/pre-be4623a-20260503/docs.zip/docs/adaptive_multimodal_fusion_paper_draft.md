# 面向 EGO-Planner 的多模态几何融合与在线自适应参数优化方法

## 摘要

针对无人机在未知障碍环境中的局部避障问题，本文基于当前 ROS 2 版 EGO-Planner 工程，设计并实现了一种面向局部规划输入的多模态几何融合方法。系统以深度点云与模拟 LiDAR 点云为输入，在统一世界坐标系下进行近似时间同步、点云裁剪、体素化表达以及基于 log-odds 的占据证据累积，输出可直接送入 `grid_map/cloud` 的融合障碍点云。与简单点云拼接不同，本文方法显式编码了近场深度优势与中远场 LiDAR 优势，并在此基础上引入三类在线自适应参数：障碍接受阈值 `min_probability`、近场切换半径 `near_field_radius` 与 LiDAR 距离增长参数 `lidar_growth`。其中，`min_probability` 与 `near_field_radius` 已在主线代码中形成稳定版本，`adaptive_lidar_growth` 则进一步改善了中远距离 LiDAR 证据权重的自适应能力。基于仓库内批量仿真与统计脚本的验证结果表明，固定 `lidar_growth=4.0` 的长时段平均 `fusion_f1_gain_vs_best_single` 达到 `+0.1105`，优于基线 `+0.1090`；在线 `adaptive_lidar_growth` 达到 `+0.1101`，保持了稳定正收益；而与 `adaptive_near_field_radius` 直接叠加时收益下降到 `+0.1090`，说明不同自适应方向之间存在耦合。实验表明，该方法能够在不改动 EGO-Planner 核心优化器的前提下，提高局部障碍感知的完整性与稳健性，并为后续规划性能提升提供更高质量的地图输入。

## 关键词

无人机避障；EGO-Planner；多模态融合；深度点云；LiDAR；在线自适应参数；ROS 2

## 1. 引言

局部规划器的性能上限在很大程度上由局部地图输入质量决定。对于 EGO-Planner 这一类以局部占据地图为核心的实时避障方法而言，若障碍观测存在系统性漏检、近远场权重分配失衡或时序抖动，则后续轨迹优化即便数值上收敛，也可能得到过于激进或过于保守的轨迹结果。

在当前工程链路中，深度点云由仿真渲染器 `pcl_render_node/cloud` 提供，近距离结构细节更丰富；模拟 LiDAR 由 `simulated_lidar_cloud.py` 基于全局障碍图生成，远距离测距与稀疏几何更稳定。二者具有明显互补性，但若采用简单并集或固定阈值融合，往往无法稳定发挥这种互补优势。为此，本文围绕当前代码实现提出两层思路：第一，在体素级构建距离自适应的概率占据证据融合；第二，在在线运行中对关键融合参数进行小范围自适应微调，使融合结果持续优于单模态输入。

本文工作的目标不是提出一个脱离工程的全新规划框架，而是在不破坏现有 EGO-Planner 局部规划结构的前提下，给出一个可运行、可验证、可持续调优的多模态感知增强方案。

## 2. 系统架构与代码落地

### 2.1 整体数据流

当前多模态仿真链路由 `single_run_in_sim_fusion.launch.py` 组织。系统主要包含以下模块：

1. 地图生成模块：使用 `mockamap` 或 `random_forest` 发布全局障碍云 `/map_generator/global_cloud`。
2. 深度感知模块：仿真渲染节点发布 `/drone_0_pcl_render_node/cloud`。
3. 模拟 LiDAR 模块：`simulated_lidar_cloud.py` 读取全局障碍云与当前里程计，生成 `/drone_0_lidar/points`。
4. 融合模块：`ros2_lidar_depth_fusion_node.py` 订阅深度点云、LiDAR 点云、里程计和全局障碍云，输出 `/drone_0_fusion/fused_cloud`。
5. 规划模块：`advanced_param.launch.py` 将融合输出重映射到 EGO-Planner 的 `grid_map/cloud` 输入。

因此，本文方法作用于“感知到规划”的接口层，而不是直接修改轨迹优化器内部的 B-spline 优化过程。

### 2.2 关键工程参数

当前代码中的主要仿真与规划参数包括：

- 地图分辨率：`0.1 m`
- 规划器速度上限：`2.0 m/s`
- 规划器加速度上限：`6.0 m/s^2`
- 规划 horizon：`7.5 m`
- 融合评估半径：`10.0 m`
- 点云高度裁剪：`z_min=-0.10`，`z_max=3.50`

这些参数来自 `single_run_in_sim_fusion.launch.py`、`advanced_param.launch.py` 与 `fusion_benefit_report.py` 的实际实现。

## 3. 多模态体素占据融合方法

### 3.1 问题定义

设深度点云与 LiDAR 点云分别为

$$
\mathcal{P}_d = \{\mathbf{p}_i^d\}, \quad \mathcal{P}_l = \{\mathbf{p}_j^l\},
$$

其中 $\mathbf{p}\in\mathbb{R}^3$ 表示世界坐标系下的点。目标是构建局部融合体素集合

$$
\mathcal{V}_f = \{\mathbf{v}_k\},
$$

并将其发布为 `PointCloud2` 供 EGO-Planner 的 `grid_map/cloud` 消费。

### 3.2 时间同步与预处理

融合节点采用 `ApproximateTimeSynchronizer` 对深度点云与 LiDAR 点云进行近似时间同步。同步后的两路点云均执行相同预处理：

1. 去除 `NaN/Inf` 非法点；
2. 按高度阈值裁剪；
3. 按相对无人机位置的最大范围裁剪；
4. 按体素分辨率量化到统一网格。

这一设计避免了直接在原始点级别做稠密拼接，也为后续局部 Ground Truth 对齐提供了统一空间表示。

### 3.3 距离自适应的模态概率模型

当前代码并未对深度与 LiDAR 采用固定等权融合，而是根据距离构造两种不同的占据概率模型。

对于深度点云，采用

$$
p_d(r)=\mathrm{clip}\left(0.25+0.55e^{-r/\lambda_d}+\mathbb{I}(r\le r_n)\cdot0.10\right),
$$

其中 $\lambda_d$ 为 `depth_decay`，$r_n$ 为 `near_field_radius`。该模型体现了“近场深度更可信”的假设。

对于 LiDAR 点云，采用

$$
p_l(r)=\mathrm{clip}\left(0.35+0.45\left(1-e^{-r/\lambda_l}\right)+\mathbb{I}(r>r_n)\cdot0.10\right),
$$

其中 $\lambda_l$ 为 `lidar_growth`。该模型体现了“LiDAR 在中远场逐步占优”的假设。

从工程角度看，`near_field_radius` 决定深度和 LiDAR 的优势切换区间，`lidar_growth` 决定 LiDAR 置信度随距离增长的快慢。

### 3.4 体素级 log-odds 证据融合

对于每个体素，系统统计深度点和 LiDAR 点的命中次数，并使用

$$
w=\min(\log(1+n),1.6)
$$

对多次命中进行增强。随后将模态概率映射为 log-odds：

$$
\ell = \log \frac{p}{1-p},
$$

并进行加权累积：

$$
L_k = \sum w_k^{(d)}\ell_k^{(d)} + \sum w_k^{(l)}\ell_k^{(l)}.
$$

最终利用 sigmoid 恢复融合概率：

$$
P_k=\sigma(L_k)=\frac{1}{1+e^{-L_k}}.
$$

若某体素满足

$$
P_k \ge P_{\min}, \quad n_k \ge n_{\min},
$$

则被保留为障碍体素。这里 `P_min` 对应 `min_probability`，`n_min` 对应 `min_hits`。当前稳定版本中，`min_hits` 保持固定为 `1`，因为更高的命中阈值在现有仿真下表现为明显负收益。

## 4. 在线自适应参数设计

### 4.1 自适应目标

当前在线自适应并不直接优化规划代价，而是优化“融合结果相对于最佳单模态的收益”。具体地，系统从 `/map_generator/global_cloud` 中截取局部 Ground Truth 体素集，并分别计算 depth、LiDAR、fusion 在局部评估半径内的 `precision`、`recall` 与 `F1`。随后构建目标函数：

$$
\mathcal{U}= \mathrm{gain}_{F1} + 0.35 \cdot \mathrm{gain}_{recall},
$$

其中

$$
\mathrm{gain}_{F1}=F1_{fusion}-\max(F1_d,F1_l),
$$

$$
\mathrm{gain}_{recall}=Recall_{fusion}-\max(Recall_d,Recall_l).
$$

这个目标函数来自代码中的实际实现，含义是：只有当融合结果真实超过最优单模态时，当前参数才被认为“有用”。

### 4.2 三类已保留的自适应参数

当前主线代码中保留了三类在线自适应参数：

1. `adaptive_min_probability`
   作用：调整障碍体素接受阈值。
   意义：控制“保留更多障碍”与“抑制噪声障碍”之间的平衡。

2. `adaptive_near_field_radius`
   作用：调整深度与 LiDAR 的近远场分界。
   意义：控制哪一段距离更多依赖深度，哪一段距离更多依赖 LiDAR。

3. `adaptive_lidar_growth`
   作用：调整 LiDAR 置信度随距离增长的速度。
   意义：控制 LiDAR 在中远场从“补充观测”变为“主导证据”的快慢。

三种自适应参数都采用相同的防抖机制：

- 候选离散集搜索；
- anchor penalty，避免偏离已验证稳定点过远；
- move penalty，避免帧间频繁抖动；
- switch margin，只有明显更优才切换；
- max delta，限制单帧最大变化幅度；
- EMA 平滑分数，降低瞬时噪声影响。

### 4.3 当前保留与回退的方向

当前版本保留的是 `adaptive_min_probability`、`adaptive_near_field_radius` 和 `adaptive_lidar_growth`。而 `adaptive_temporal_decay`、`dual_confirmation_bonus` 以及更高的 `min_hits` 方案已在仓库内实验过，但因长时段指标不稳定或负收益被回退。这个结论不是经验判断，而是由批量脚本跑出的 summary 文件支持。

## 5. 实验设计

### 5.1 评测方法

本文实验采用仓库中的 `tools/compare_fusion.sh` 与 `fusion_benefit_report.py` 自动完成。评测流程如下：

1. 启动融合仿真与规划链路；
2. 订阅 depth、LiDAR、fusion 与 global obstacle cloud；
3. 在局部范围内构建 Ground Truth 体素；
4. 逐帧计算三类输入的 `precision / recall / F1`；
5. 统计 `fusion_recall_gain_vs_best_single` 与 `fusion_f1_gain_vs_best_single`；
6. 输出 CSV 与 `summary.json`。

本文主要关注的指标是：

- `fusion_f1_gain_vs_best_single`
- `fusion_recall_gain_vs_best_single`
- `positive_ratio_f1_gain`

这三项指标能够直接回答“融合是否真的优于最强单模态”。

### 5.2 长时段对比结果

表 1 给出了当前稳定主线上的长时段结果。

| 配置 | fusion_recall | fusion_f1 | F1 gain vs best single | Recall gain vs best single |
|---|---:|---:|---:|---:|
| baseline (`lidar_growth=5.0`) | 0.1671 | 0.2861 | +0.1090 | +0.0699 |
| fixed `lidar_growth=4.0` | 0.1691 | 0.2891 | +0.1105 | +0.0710 |
| online `adaptive_lidar_growth` | 0.1686 | 0.2882 | +0.1101 | +0.0707 |
| online `adaptive_near_field_radius` | 0.1683 | 0.2879 | +0.1113 | +0.0714 |
| `adaptive_near + adaptive_lidar` | 0.1669 | 0.2857 | +0.1090 | +0.0699 |

所有上述实验的 `positive_ratio_f1_gain` 均为 `1.0`，说明在统计窗口中融合结果持续优于最佳单模态。

### 5.3 结果分析

从表 1 可以看到：

1. 单独把 `lidar_growth` 从默认 `5.0` 调整为 `4.0`，长时段收益稳定提升，说明 LiDAR 在当前地图和量程设置下应更早进入高置信区间。
2. `adaptive_lidar_growth` 的在线版本虽然略低于固定最优点 `4.0`，但仍优于 baseline，说明这条自适应方向是成立的。
3. `adaptive_near_field_radius` 单独启用时表现最好，说明“近远场切换位置”仍是当前系统最敏感的自适应因子。
4. 将 `adaptive_lidar_growth` 与 `adaptive_near_field_radius` 直接叠加后，整体收益下降，表明两个参数都作用于“距离相关权重分配”，存在明显耦合。

因此，当前主线工程更适合将 `adaptive_lidar_growth` 视为独立可选项，而不是默认与 `adaptive_near_field_radius` 叠加开启。

### 5.4 基于现有数据的进一步分析

仅从绝对值看，几组配置之间的差异并不大，但把它们和同一基线做相对比较后，趋势会更清楚。

首先，固定 `lidar_growth=4.0` 相比 baseline 的提升是稳定且方向一致的。以长时段统计为例：

- `fusion_f1` 从 `0.2861` 提升到 `0.2891`，相对提升约 `1.02%`
- `fusion_recall` 从 `0.1671` 提升到 `0.1691`，相对提升约 `1.18%`
- `fusion_f1_gain_vs_best_single` 从 `+0.1090` 提升到 `+0.1105`，相对提升约 `1.41%`
- `fusion_recall_gain_vs_best_single` 从 `+0.0699` 提升到 `+0.0710`，相对提升约 `1.62%`

这说明当前数据支持如下判断：`lidar_growth` 的主要贡献不是“把融合点云做得特别密”，而是在相近点云规模下，让 LiDAR 证据更早进入有效区间，从而提升了融合结果相对于最优单模态的净收益。

其次，在线 `adaptive_lidar_growth` 的数据表明，这个自适应方向是成立的，但环境复杂度还不足以让它频繁切换。对 `adaptive_lidar_anchor4_long.trace.csv` 的统计显示：

- `current_lidar_growth` 在 `240` 帧内全部为 `4.0`
- `current_near_field_radius` 在同一实验中全部保持 `1.5`
- `current_min_probability` 全部保持 `0.2`
- 平均 `retention_ratio` 为 `1.0`
- 平均 `fused_voxels` 为 `10442.13`

这组数据意味着，在线 `adaptive_lidar_growth` 的收益主要来自“把搜索范围收缩到正确甜点后稳定工作”，而不是来自大幅度在线摆动。从论文角度看，这反而是一个更强的工程结论：当前在线策略已经足够保守，不会因为频繁切换而破坏地图稳定性。

再次，`adaptive_near_field_radius` 在当前数据里比 `adaptive_lidar_growth` 更敏感。对 `adaptive_near_long.trace.csv` 的统计显示，`near_field_radius` 在 `127` 帧中有 `123` 帧保持 `1.5`，仅有 `1` 帧取 `1.75`、`3` 帧取 `2.0`。也就是说，这个参数虽然同样是“以稳定为主”，但确实会在少量时刻向更大半径试探，并且这种有限试探带来了当前最好的长时段收益 `+0.1113`。这说明在现有仿真中，近远场分界位置仍然是最值得优先优化的融合参数。

最后，参数叠加失败的数据也具有分析价值。`adaptive_near + adaptive_lidar` 相比 baseline 的 `fusion_f1_gain_vs_best_single` 几乎没有提升，且 `fusion_f1`、`fusion_recall` 还分别下降约 `0.15%` 与 `0.16%`。同时，其 trace 数据表明：

- `current_lidar_growth` 始终固定在 `4.0`
- `current_near_field_radius` 绝大多数时间停留在 `1.5`，仅少量帧试探 `1.75/2.0`
- 平均 `fused_voxels` 下降到 `10355.16`

这说明当前两个自适应方向存在明显耦合：二者都作用于“距离相关权重分配”，同时启用时并没有形成互补，反而压缩了有效障碍体素数量。换言之，当前数据支持“分开优化、分开启用”，而不支持“所有在线自适应一起打开”。

综合这些结果，可以得到一个更完整的数据结论：当前系统中，自适应参数的收益主要来自“把参数约束在一个正确且稳定的局部最优区域”，而不是来自大范围在线搜索。这个结论决定了后续优化策略应继续采用小范围、带锚点、强防抖的在线调参框架，而不是扩大搜索空间。

## 6. 方法优势与局限

### 6.1 优势

本文方法具有以下优点：

- 不改动 EGO-Planner 核心优化器，只增强感知输入层；
- 通过标准 `PointCloud2` 接口与现有 `grid_map/cloud` 无缝兼容；
- 算法轻量，易于在 ROS 2 工程中调参与批量验证；
- 自适应目标直接面向“超过最佳单模态”，避免了只追求更密点云的伪收益；
- 支持用 batch 脚本快速验证每个新参数方向是否值得保留。

### 6.2 局限

当前实现仍存在以下限制：

- 仿真中深度与 LiDAR 都工作在统一 `world` 坐标系，尚未体现真实外参与时延误差；
- 评测指标主要是局部障碍感知质量，而非轨迹长度、耗时或最小安全距离；
- `adaptive_lidar_growth` 在线版在当前实现中多数时间收敛到固定甜点 `4.0`，说明环境变化对其触发的需求尚不强；
- 不同自适应参数之间存在耦合，简单叠加并不一定带来更好结果。

## 7. 结论与后续工作

本文基于当前 ROS 2 EGO-Planner 工程实现，提出并验证了一种面向局部规划输入的多模态几何融合与在线自适应参数优化方法。该方法通过体素级 log-odds 证据融合，将深度点云与 LiDAR 点云的几何互补性转化为更稳定的障碍体素集合；并通过 `adaptive_min_probability`、`adaptive_near_field_radius` 与 `adaptive_lidar_growth` 三类在线参数，实现了对融合行为的小范围自适应调节。

实验表明，`adaptive_lidar_growth` 是一条成立的新方向，能够在长时段评测中保持相对于 baseline 的正收益；同时也表明并非所有自适应参数叠加都能进一步提升性能。当前最合理的工程结论是：保留多条已验证的自适应方向，但按耦合关系分开启用和验证。

后续工作可沿以下方向继续推进：

1. 将感知质量提升进一步映射到规划指标，如重规划成功率、最小障碍距离和任务完成时间；
2. 引入真实 TF 外参与时间延迟补偿，验证方法在真机链路中的稳健性；
3. 研究 planner 侧自适应参数，如 obstacle inflation 或 collision cost；
4. 在时序融合层面引入更稳健的状态机式策略，而不是单纯增加自由衰减参数。

## 附录：本文对应的核心代码与实验文件

- 融合节点：
  `src/planner/plan_manage/scripts/ros2_lidar_depth_fusion_node.py`
- 仿真启动：
  `src/planner/plan_manage/launch/single_run_in_sim_fusion.launch.py`
- 规划接入：
  `src/planner/plan_manage/launch/advanced_param.launch.py`
- 批量评测脚本：
  `tools/compare_fusion.sh`
- 评测节点：
  `src/planner/plan_manage/scripts/fusion_benefit_report.py`
- 本文关键结果：
  `artifacts/adaptive_lidar_growth_long_20260413/`
  `artifacts/adaptive_lidar_plus_near_long_20260413/`
  `artifacts/near_tune_long_20260412/`
